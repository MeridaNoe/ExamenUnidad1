package Server;

import java.util.ArrayList;
import java.util.List;

public class Methods {

    public String generate(String Nombre, String primerApe, String segundoApe, String sexo, String estado, String fecha, String Nombre2, int ultimonumero, char ultimaletra) {
        Nombre.charAt(0);
        primerApe.substring(0, 1);
        segundoApe.charAt(0);
        sexo.charAt(0);
        fecha.substring(2, 8);
        ultimonumero = (int) Math.random();
        ultimaletra = (char) (ultimaletra.nextInt(26) + 'a');
        Nombre2. (3, 9, 15); //MERIDA PUENTE NOE
        String result = "";
        if (estado == "Aguascalientes") ;
        {
            estado = "AS";
        }
        if (estado == "BajaCalifornia") ;
        {
            estado = "BC";
        }
        if (estado == "BajaCaliforniaSur") ;
        {
            estado = "BS";
        }
        if (estado == "Campeche") ;
        {
            estado = "CC";
        }
        if (estado == "Coahuila") ;
        {
            estado = "CL";
        }
        if (estado == "Colima") ;
        {
            estado = "CM";
        }
        if (estado == "Chiapas") ;
        {
            estado = "CS";
        }
        if (estado == "Chihuahua") ;
        {
            estado = "CH";
        }
        if (estado == "DistritoFederal") ;
        {
            estado = "DF";
        }
        if (estado == "Durango") ;
        {
            estado = "DG";
        }
        if (estado == "Guanajuato") ;
        {
            estado = "GT";
        }
        if (estado == "Guerrero") ;
        {
            estado = "GR";
        }
        if (estado == "Hidalgo") ;
        {
            estado = "HG";
        }
        if (estado == "Jalisco") ;
        {
            estado = "JC";
        }
        if (estado == "Mexico") ;
        {
            estado = "MC";
        }
        if (estado == "Michoacan") ;
        {
            estado = "MN";
        }
        if (estado == "Morelos") ;
        {
            estado = "MS";
        }
        if (estado == "Nayarit") ;
        {
            estado = "NT";
        }
        if (estado == "NuevoLeon") ;
        {
            estado = "NL";
        }
        if (estado == "Oaxaca") ;
        {
            estado = "OC";
        }
        if (estado == "Puebla") ;
        {
            estado = "PL";
        }
        if (estado == "Queretaro") ;
        {
            estado = "QT";
        }
        if (estado == "QuintanaRoo") ;
        {
            estado = "QR";
        }
        if (estado == "SanLuisPotosi") ;
        {
            estado = "SP";
        }
        if (estado == "Sinaloa") ;
        {
            estado = "SL";
        }
        if (estado == "Sonora") ;
        {
            estado = "SR";
        }
        if (estado == "Tabasco") ;
        {
            estado = "TC";
        }
        if (estado == "Tamaulipas") ;
        {
            estado = "TS";
        }
        if (estado == "Tlaxcala") ;
        {
            estado = "TL";
        }
        if (estado == "Veracruz") ;
        {
            estado = "VZ";
        }
        if (estado == "Yucatan") ;
        {
            estado = "YN";
        }
        if (estado == "Zacatecas") ;
        {
            estado = "ZS";
        }
        if (estado == "NacidoEnElExtranjero") ;
        {
            estado = "NE";
        }
        System.out.println("tu CURP es: " + primerApe + segundoApe + Nombre + fecha + estado);
        return result;
    }

}
