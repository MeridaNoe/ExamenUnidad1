package Server;

public class BeanCurp {
    /*
     id bigint  not null auto_increment,
    Nombre varchar(30),
    Primer_Ape varchar(30),
    Segundo_Ape varchar(30),
    Sexo varchar (10),
    Estado_Nac varchar (50),
    Fecha_Nac varchar (20)
     */
    private long id;
    private String Nombre;
    private String Primer_Ape;
    private String Segundo_Ape;
    private String Sexo;
    private String Estado_Nac;
    private String Fecha_Nac;

    private String CURP;

    public BeanCurp() {

    }

    public BeanCurp(long id, String nombre, String primer_Ape, String segundo_Ape, String sexo, String estado_Nac, String fecha_Nac, String CURP) {
        this.id = id;
        this.Nombre = nombre;
        this.Primer_Ape = primer_Ape;
        this.Segundo_Ape = segundo_Ape;
        this.Sexo = sexo;
        this.Estado_Nac = estado_Nac;
        this.Fecha_Nac = fecha_Nac;
        this.CURP = CURP;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getPrimer_Ape() {
        return Primer_Ape;
    }

    public void setPrimer_Ape(String primer_Ape) {
        Primer_Ape = primer_Ape;
    }

    public String getSegundo_Ape() {
        return Segundo_Ape;
    }

    public void setSegundo_Ape(String segundo_Ape) {
        Segundo_Ape = segundo_Ape;
    }

    public String getSexo() {
        return Sexo;
    }

    public void setSexo(String sexo) {
        Sexo = sexo;
    }

    public String getEstado_Nac() {
        return Estado_Nac;
    }

    public void setEstado_Nac(String estado_Nac) {
        Estado_Nac = estado_Nac;
    }

    public String getFecha_Nac() {
        return Fecha_Nac;
    }

    public void setFecha_Nac(String fecha_Nac) {
        Fecha_Nac = fecha_Nac;
    }

    public String getCURP() {
        return CURP;
    }

    public void setCURP(String CURP) {
        this.CURP = CURP;
    }
}
