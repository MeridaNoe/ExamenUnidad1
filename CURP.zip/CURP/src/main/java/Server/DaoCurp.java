package Server;
import Utils.MySQLConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoCurp {
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;

    public List<BeanCurp> showDatos() {
        List<BeanCurp> datos = new ArrayList<>();
        BeanCurp dato = null;
        try {
            conn = new MySQLConnection().getConnection();
            pstm = conn.prepareStatement("SELECT * FROM Datos;");
            rs = pstm.executeQuery();
            while (rs.next()) {
                dato = new BeanCurp();
                dato.setId(rs.getLong("id"));
                dato.setNombre(rs.getString("Nombre"));
                dato.setPrimer_Ape(rs.getString("Primer_Ape"));
                dato.setSegundo_Ape(rs.getString("Segundo_Ape"));
                dato.setSexo(rs.getString("Sexo"));
                dato.setEstado_Nac(rs.getString("Estado_Nac"));
                dato.setFecha_Nac(rs.getString("Fecha_Nac"));
                dato.setCURP(rs.getString("CURP"));
                datos.add(dato);
            }
        }catch (SQLException e){
            Logger.getLogger(DaoCurp.class.getName()).log(Level.SEVERE, "Error showDatos", e);
        }finally {
            closeConnection();
        }
        return datos;
    }

    public boolean saveDatos(BeanCurp curp) {
        try{
            conn = new MySQLConnection().getConnection();
            pstm = conn.prepareStatement("INSERT INTO Datos (Nombre, Primer_Ape, Segundo_Ape, Sexo, Estado_Nac, Fecha_Nac)" +
                    "VALUES (?, ?, ?, ?, ?, ?)");
            pstm.setString(1, curp.getNombre());
            pstm.setString(2, curp.getPrimer_Ape());
            pstm.setString(3, curp.getSegundo_Ape());
            pstm.setString(4, curp.getSexo());
            pstm.setString(5, curp.getEstado_Nac());
            pstm.setString(6, curp.getFecha_Nac());
            return pstm.executeUpdate() == 1;
            //conn.commit();
        }catch (SQLException e){
            Logger.getLogger(DaoCurp.class.getName()).log(Level.SEVERE, "Error saveDatos", e);
        }finally {
            closeConnection();
        }
        return false;
    }
    public void closeConnection(){
        try{
            if(conn != null){
                conn.close();
            }
            if(pstm != null){
                pstm.close();
            }
            if(rs != null){
                rs.close();
            }
        }catch (SQLException e){

        }
    }
}


