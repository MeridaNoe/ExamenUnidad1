package Client;

import Server.BeanCurp;
import Server.DaoCurp;
import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;
import Server.BeanCurp;
import Server.DaoCurp;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class RPCClient {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) throws MalformedURLException, XmlRpcException {
        XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
        config.setServerURL(new URL("http://localhost:1200"));
        XmlRpcClient client = new XmlRpcClient();
        client.setConfig(config);
        BeanCurp curp = new BeanCurp();
        DaoCurp ac = new DaoCurp();
        String Nombre = "", Nombre2="", primerApe, segundoApe, sexo, estado, fecha, CURP;
        System.out.println("Ingrese su Nomrbe: ");
        String s = "";
        Nombre.equalsIgnoreCase(s);
        Nombre = Nombre2;
        System.out.println("Ingrese su Primer Apellido");
        primerApe =sc.next();
        System.out.println("Ingrese su Segundo Apellido");
        segundoApe =sc.next();
        System.out.println("Ingrese su Sexo");
        sexo =sc.next();
        System.out.println("Ingrese su Estado de Nacimiento");
        estado =sc.next();
        System.out.println("Ingrese su Fecha de Nacimiento");
        fecha =sc.next();

        Object[] datos = {Nombre, primerApe, segundoApe, sexo, estado, fecha};
        String dato = (String) client.execute("Methods.generate", datos);
        System.out.println("Tu CURP es: " + dato);
        curp.setCURP(String.valueOf(datos));
        ac.saveDatos(curp);
    }
}
